// 모든 GUI는 main에서 구현, 나머지 클래스파일에서는 자리 예약 기능, 회원 등록에 필요한 기능들만 구현
import java.io.* ;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Database DB = new Database();
        DatabaseGUI DBGUI = new DatabaseGUI(DB);
    }
}