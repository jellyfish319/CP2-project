import javax.swing.*;
import java.io.*;
import java.util.*;

public class Database {
    public Database() throws IOException, ClassNotFoundException {
        customerDatabase = new HashMap<>();
        showList = new ArrayList<>();
        // 유저 정보 초기화
        File userDirectory = new File("./src/data/user");
        if (userDirectory.exists() && userDirectory.isDirectory()) {
            File[] userFiles = userDirectory.listFiles((dir, name) -> name.endsWith(".txt"));
            if (userFiles != null) {
                for (File userFile : userFiles) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(userFile))) {
                        String id = reader.readLine();
                        String password = reader.readLine();
                        String name = reader.readLine();
                        String email = reader.readLine();
                        String phone = reader.readLine();
                        Customer customer = new Customer(id, password, name, email, phone);
                        customerDatabase.put(id, customer);
                    } catch (IOException e) {
                        System.err.println("Error reading user file: " + userFile.getName());
                    }
                }
            }
        } else {
            System.err.println("User directory not found: " + userDirectory.getPath());
        }

        // 영화 정보 초기화
        File movieDirectory = new File("./src/data/movie");
        //System.out.println("Current Working Directory: " + System.getProperty("user.dir"));
        //System.out.println("User Directory Path: " + userDirectory.getAbsolutePath());
        //System.out.println("Movie Directory Path: " + movieDirectory.getAbsolutePath()); // 디버깅 코드

        if (movieDirectory.exists() && movieDirectory.isDirectory()) {
            File[] movieFiles = movieDirectory.listFiles((dir, name) -> name.endsWith(".txt"));
            if (movieFiles != null) {
                for (File movieFile : movieFiles) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(movieFile))) {
                        String name = reader.readLine();
                        String director = reader.readLine();
                        String genre = reader.readLine();
                        int runtime = Integer.parseInt(reader.readLine());
                        String imagePath = reader.readLine();
                        int totalSeats = Integer.parseInt(reader.readLine());
                        ImageIcon icon = new ImageIcon(imagePath);
                        int remain = Integer.parseInt(reader.readLine());
                        Show show = new Show(name, director, genre, runtime, icon, totalSeats, remain);
                        showList.add(show);
                    } catch (IOException | NumberFormatException e) {
                        System.err.println("Error reading movie file: " + movieFile.getName());
                    }
                }
            }
        } else {
            System.err.println("Movie directory not found: " + movieDirectory.getPath());
        }
    }

    public void SignUp(String id, String password, String name, String email, String phone) throws IOException {
        if (customerDatabase.containsKey(id)) {
            throw new IllegalArgumentException("ID가 이미 존재합니다.");
        }
        Customer customer = new Customer(id, password, name, email, phone);
        customerDatabase.put(id, customer);
        customer.clearReservationFile();

        // 유저 정보를 개별 텍스트 파일로 저장
        File userFile = new File("./src/data/user/" + id + ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(userFile))) {
            writer.write(id);
            writer.newLine();
            writer.write(password);
            writer.newLine();
            writer.write(name);
            writer.newLine();
            writer.write(email);
            writer.newLine();
            writer.write(phone);
        }
    }

    public Customer LoadUser(String id) {
        return customerDatabase.get(id);
    }

    public boolean CheckID(String id) {
        return customerDatabase.containsKey(id);
    }

    public String LoginText(String id, String password) {
        if (customerDatabase.containsKey(id)) {
            Customer c = customerDatabase.get(id);
            if (c.getPassword().equals(password)) {
                return null;
            } else {
                return "비밀번호가 틀렸습니다.";
            }
        } else {
            return "없는 아이디입니다.";
        }
    }

    public boolean LoginCheck(String id, String password) {
        if (customerDatabase.containsKey(id)) {
            Customer c = customerDatabase.get(id);
            return c.getPassword().equals(password);
        }
        return false;
    }

    public void AddShow(String name, String director, String genre, int runtime, String path, int totalseats, int remain) throws IOException {
        ImageIcon icon = new ImageIcon(path);
        Show show = new Show(name, director, genre, runtime, icon, totalseats, remain);
        showList.add(show);

        // 영화 정보를 개별 텍스트 파일로 저장
        File movieFile = new File("./src/data/movie/" + name.replaceAll("\\s+", "_") + ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(movieFile))) {
            writer.write(name);
            writer.newLine();
            writer.write(director);
            writer.newLine();
            writer.write(genre);
            writer.newLine();
            writer.write(runtime);
            writer.newLine();
            writer.write(path);
            writer.newLine();
            writer.write(totalseats);
            writer.newLine();
            writer.write(remain);
        }
    }

    public Show ShowList(int i) {
        return showList.get(i);
    }

    public Show ShowList(String showname) {
        for (Show show : showList) {
            if (show.getName().equalsIgnoreCase(showname)) {
                return show; // 이름이 일치하는 쇼를 반환
            }
        }
        return null; // 일치하는 쇼가 없는 경우 null 반환
    }

    public int ShowSize() {
        return showList.size();
    }

    private HashMap<String, Customer> customerDatabase;
    private List<Show> showList;
}

// 기존 파일 헤더를 덮어쓰지 않는 ObjectOutputStream 구현
class AppendableObjectOutputStream extends ObjectOutputStream {
    public AppendableObjectOutputStream(OutputStream out) throws IOException {
        super(out);
    }

    @Override
    protected void writeStreamHeader() throws IOException {
        // 기존 파일의 헤더를 덮어쓰지 않음
        reset();
    }
}
