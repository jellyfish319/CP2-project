import java.io.*;
import java.util.ArrayList;

public class Customer {
    private String name;
    private String customerID;
    private String password;
    private String phone;
    private String email;
    public ArrayList<Seat> mySeat = new ArrayList<>();
    private ArrayList<String> coupons;
    public Show myshow;
    private Payment payment;
    // 등록된 결제수단으로 결제하는 것은 향후 업데이트 예정

    public Customer(String id, String password, String name, String email, String phoneNumber) {
        this.customerID = id;
        this.password = password;
        this.name = name;
        this.email = email;
        this.phone = phoneNumber;
        this.coupons = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public ArrayList<Seat> getMySeat() {
        return mySeat;
    }

    public void cancelSeatReservation() {
        myshow.removeSeat(mySeat);
        clearReservationFile();
        myshow.remain += mySeat.size();
        FileLastLineUpdater.updateLastLine(myshow.seatpath, Integer.toString(myshow.remain));
        this.mySeat = new ArrayList<>();
        this.myshow = null;
    }

    public ArrayList<String> getCoupons() {
        return coupons;
    }

    public void addCoupon(String coupon) {
        coupons.add(coupon);
    }

    public Payment getPaymentInfo() {
        return payment;
    }

    public void setPaymentInfo(Payment payment) {
        this.payment = payment;
    }

    public String printSeat() {
        return myshow.getName() + " : " + mySeat.toString();
    }

    // 좌석 정보 업데이트
    public void updateSeat(ArrayList<Seat> newSeats, String showname) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("./src/data/user_seat/" + customerID + ".txt"));
        try {
            for (Seat seat : newSeats) {
                writer.write(seat.toString());
                writer.newLine();
            }
        } finally {
            writer.write(showname);
            writer.close();
        }
    }

    // 좌석 정보 불러오기
    public void loadSeat(Database database) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("./src/data/user_seat/" + customerID + ".txt"));
        mySeat = new ArrayList<>();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                if (reader.ready()) {
                    char rowNum = line.charAt(0); // 행 번호
                    int colNum = Integer.parseInt(line.substring(1)); // 열 번호
                    mySeat.add(new Seat(rowNum, colNum)); // 좌석 리스트에 추가
                } else {
                    myshow = database.ShowList(line);
                }
            }
        } finally {
            reader.close(); // BufferedReader 닫기
        }
    }

    public void clearReservationFile() {
        String filePath = "./src/data/user_seat/" + customerID + ".txt";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // 아무 내용도 쓰지 않으면 기존 내용을 덮어쓰고 빈 파일로 만듦
        } catch (IOException e) {
            System.err.println("Error clearing file: " + filePath);
            e.printStackTrace();
        }
    }
}
