
public class Payment {
    private String cardNumber;
    private String expiryDate;
    private String cvc;
    private String cardPassword;

    public Payment(String cardNumber, String expiryDate, String cvc, String cardPassword) {
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
        this.cvc = cvc;
        this.cardPassword = cardPassword;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public String getCvc() {
        return cvc;
    }

    public String getCardPassword() {
        return cardPassword;
    }

    @Override
    public String toString() {
        return "카드번호: " + cardNumber + " / 만료일: " + expiryDate;
    }
}