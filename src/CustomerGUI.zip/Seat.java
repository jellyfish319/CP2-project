public class Seat {
    char rowNum;
    int colNum;
    boolean reserved;
    char type;
    boolean selected;

    public Seat(char rowNum, int colNum) {
        this.rowNum = rowNum;
        this.colNum = colNum;
        this.reserved = false;
        this.selected = false;
    }

    public void reserve() {
        this.reserved = true;
    }

    public void cancelReservation() {
        this.reserved = false;
    }

    public boolean isReserved() {
        return reserved;
    }

    public void select() {
        this.selected = true;
    }

    public void cancelSeleection() {
        this.selected = false;
    }
    public boolean isSelected() {
        return selected;
    }

    @Override
    public String toString() {
        return Character.toString(rowNum) + colNum;
    }

    @Override
    public boolean equals(Object obj) {
        Seat cont = (Seat) obj;
        return (cont.toString().equals(toString()));
    }
}