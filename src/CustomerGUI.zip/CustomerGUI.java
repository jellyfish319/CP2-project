import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class CustomerGUI extends JFrame {
    private JTextField txtName, txtPhone;
    private JLabel lblSeatInfo;
    private JComboBox<String> couponComboBox;
    private JButton btnEditInfo, btnCancelReservation, btnDeleteAccount, btnManagePayment, btnViewCards;

    public CustomerGUI(Database database, Customer customer) throws IOException {
        customer.loadSeat(database);
        setTitle("Customer Management");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        setResizable(false);

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(5, 2, 10, 10));
        infoPanel.setBorder(BorderFactory.createTitledBorder("고객 정보"));
        infoPanel.setBackground(new Color(240, 248, 255));

        txtName = new JTextField(customer.getName());
        txtName.setEditable(false);
        txtPhone = new JTextField(customer.getPhone());
        txtPhone.setEditable(false);

        lblSeatInfo = new JLabel(
                customer.getMySeat().isEmpty() ? "예약된 좌석 없음" : customer.printSeat()
        );
        lblSeatInfo.setForeground(Color.DARK_GRAY);
        lblSeatInfo.setHorizontalAlignment(SwingConstants.CENTER);

        couponComboBox = new JComboBox<>();
        if (customer.getCoupons() == null || customer.getCoupons().isEmpty()) {
            couponComboBox.addItem("사용 가능한 쿠폰 없음");
        } else {
            for (String coupon : customer.getCoupons()) {
                couponComboBox.addItem(coupon);
            }
        }

        infoPanel.add(new JLabel("이름:"));
        infoPanel.add(txtName);
        infoPanel.add(new JLabel("연락처:"));
        infoPanel.add(txtPhone);
        infoPanel.add(new JLabel("예약 좌석:"));
        infoPanel.add(lblSeatInfo);
        infoPanel.add(new JLabel("보유 쿠폰:"));
        infoPanel.add(couponComboBox);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 5, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        Color buttonColor = new Color(100, 149, 237);
        Font buttonFont = new Font("SansSerif", Font.BOLD, 14);

        btnEditInfo = createButton("정보 수정", buttonColor, buttonFont);
        btnEditInfo.addActionListener(e -> openEditInfoDialog(customer));

        btnCancelReservation = createButton("예약 취소", buttonColor, buttonFont);
        btnCancelReservation.addActionListener(e -> {
            customer.cancelSeatReservation();
            lblSeatInfo.setText("예약된 좌석 없음");
            JOptionPane.showMessageDialog(this, "좌석 예약이 취소되었습니다!");
        });

        btnDeleteAccount = createButton("계정 삭제", buttonColor, buttonFont);
        btnDeleteAccount.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this, "정말 계정을 삭제하시겠습니까?", "계정 삭제", JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "계정이 삭제되었습니다.");
                dispose();
            }
        });

        btnViewCards = createButton("카드 목록 확인", buttonColor, buttonFont);
        btnViewCards.addActionListener(e -> openCardListDialog(customer));


        btnManagePayment = createButton("결제수단 관리", buttonColor, buttonFont);
        btnManagePayment.addActionListener(e -> openPaymentInfoDialog(customer));

        buttonPanel.add(btnEditInfo);
        buttonPanel.add(btnCancelReservation);
        buttonPanel.add(btnDeleteAccount);
        buttonPanel.add(btnManagePayment);
        buttonPanel.add(btnViewCards);

        JButton closeButton = createButton("닫기", buttonColor, buttonFont);
        closeButton.addActionListener(e -> dispose());
        buttonPanel.add(closeButton);

        add(infoPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JButton createButton(String text, Color color, Font font) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(font);
        return button;
    }

    private void openCardListDialog(Customer customer) {
        JDialog cardListDialog = new JDialog(this, "등록된 카드 목록", true);
        cardListDialog.setSize(400, 300);
        cardListDialog.setLayout(new BorderLayout());
        cardListDialog.setLocationRelativeTo(this);

        // 카드 목록이 없을 경우 메시지 표시
        if (customer.getPaymentInfo() == null) {
            JLabel noCardLabel = new JLabel("등록된 카드가 없습니다.", SwingConstants.CENTER);
            noCardLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
            cardListDialog.add(noCardLabel, BorderLayout.CENTER);
        } else {
            // 카드 정보 표시
            JTextArea cardInfoArea = new JTextArea();
            cardInfoArea.setEditable(false);
            cardInfoArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
            cardInfoArea.setText("카드 정보:\n\n" + customer.getPaymentInfo().toString());

            JScrollPane scrollPane = new JScrollPane(cardInfoArea);
            cardListDialog.add(scrollPane, BorderLayout.CENTER);
        }

        // 닫기 버튼
        JButton closeButton = new JButton("닫기");
        closeButton.addActionListener(e -> cardListDialog.dispose());
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(closeButton);

        cardListDialog.add(buttonPanel, BorderLayout.SOUTH);
        cardListDialog.setVisible(true);
    }

    private void openEditInfoDialog(Customer customer) {
        Color buttonColor = new Color(100, 149, 237);
        Font buttonFont = new Font("SansSerif", Font.BOLD, 14);
        JDialog editDialog = new JDialog(this, "정보 수정", true);
        editDialog.setSize(300, 250);
        editDialog.setLayout(new GridLayout(4, 2, 10, 10));
        editDialog.setLocationRelativeTo(this);

        JTextField txtName = new JTextField(customer.getName());
        JTextField txtPassword = new JTextField(customer.getPassword());
        JTextField txtPhone = new JTextField(customer.getPhone());

        JButton btnSave = createButton("저장", buttonColor, buttonFont);
        btnSave.addActionListener(e -> {
            customer.setName(txtName.getText());
            customer.setPassword(txtPassword.getText());
            customer.setPhone(txtPhone.getText());

            this.txtName.setText(customer.getName());
            this.txtPhone.setText(customer.getPhone());

            JOptionPane.showMessageDialog(editDialog, "정보가 수정되었습니다!");
            editDialog.dispose();
        });

        JButton btnCancel = createButton("취소", buttonColor, buttonFont);
        btnCancel.addActionListener(e -> editDialog.dispose());

        editDialog.add(new JLabel("새 이름:"));
        editDialog.add(txtName);
        editDialog.add(new JLabel("새 비밀번호:"));
        editDialog.add(txtPassword);
        editDialog.add(new JLabel("새 연락처:"));
        editDialog.add(txtPhone);
        editDialog.add(btnSave);
        editDialog.add(btnCancel);

        editDialog.setVisible(true);
    }

    private void openPaymentInfoDialog(Customer customer) {
        Color buttonColor = new Color(100, 149, 237);
        Font buttonFont = new Font("SansSerif", Font.BOLD, 14);
        JDialog paymentDialog = new JDialog(this, "결제수단 관리", true);
        paymentDialog.setSize(400, 300);
        paymentDialog.setLayout(new GridLayout(5, 2, 10, 10));
        paymentDialog.setLocationRelativeTo(this);

        JTextField txtCardNumber = new JTextField();
        JTextField txtExpiryDate = new JTextField();
        JTextField txtCVC = new JTextField();
        JTextField txtCardPassword = new JTextField();

        JButton btnSave = createButton("저장", buttonColor, buttonFont);
        btnSave.addActionListener(e -> {
            String cardNumber = txtCardNumber.getText();
            String expiryDate = txtExpiryDate.getText();
            String cvc = txtCVC.getText();
            String cardPassword = txtCardPassword.getText();

            if (cardNumber.length() == 19 && expiryDate.matches("\\d{4} / \\d{2}") &&
                    cvc.length() == 3 && cardPassword.length() == 4) {
                customer.setPaymentInfo(new Payment(cardNumber, expiryDate, cvc, cardPassword));
                JOptionPane.showMessageDialog(paymentDialog, "결제수단이 저장되었습니다.");
                paymentDialog.dispose();
            } else {
                JOptionPane.showMessageDialog(paymentDialog, "입력 형식이 잘못되었습니다.");
            }
        });

        JButton btnCancel =createButton("취소", buttonColor, buttonFont);
        btnCancel.addActionListener(e -> paymentDialog.dispose());

        paymentDialog.add(new JLabel("카드번호 (xxxx-xxxx-xxxx-xxxx):"));
        paymentDialog.add(txtCardNumber);
        paymentDialog.add(new JLabel("만료일 (YYYY / MM):"));
        paymentDialog.add(txtExpiryDate);
        paymentDialog.add(new JLabel("CVC:"));
        paymentDialog.add(txtCVC);
        paymentDialog.add(new JLabel("카드 비밀번호 앞 두자리:"));
        paymentDialog.add(txtCardPassword);
        paymentDialog.add(btnSave);
        paymentDialog.add(btnCancel);

        paymentDialog.setVisible(true);
    }
}
