import java.io.*;
import java.util.*;

public class FileLastLineUpdater {
    public static void updateLastLine(String filePath, String newLastLine) {
        List<String> lines = new ArrayList<>();

        // 파일 읽기
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line); // 각 줄을 리스트에 저장
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + filePath);
            e.printStackTrace();
            return;
        }

        // 마지막 줄 변경
        if (!lines.isEmpty()) {
            lines.set(lines.size() - 1, newLastLine); // 마지막 줄 업데이트
        } else {
            lines.add(newLastLine); // 파일이 비어있다면 새 줄 추가
        }

        // 파일 쓰기
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing to file: " + filePath);
            e.printStackTrace();
        }
    }
}
