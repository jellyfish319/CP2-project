import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

// 공연정보 열람 및 공연 예약을 수행할 수 있는 클래스

public class Show {
    String name;
    int totalSeats;
    Seat[][] seats;
    String director;
    String genre;
    int runtime;
    ImageIcon icon;
    int remain;
    String respath;
    String seatpath;


    // Theater 객체가 없기에 우선 좌석 개수는 하드코딩
    int row = 5;
    int col = 5;

    public Show(String name, String director, String genre, int runtime, ImageIcon icon, int totalSeats, int remain) throws FileNotFoundException {
        this.name = name;
        this.totalSeats = totalSeats;
        this.seats = new Seat[row][col];
        this.director = director;
        this.runtime = runtime;
        this.genre = genre;
        this.icon = icon;
        this.remain = remain;
        this.respath =  "./src/data/resInfo/" + name + ".txt";
        this.seatpath = "./src/data/movie/" + name + ".txt";
        initializeSeats();
        initializeResInfo();
    }

//    public List<Seat> getAvailableSeats() {
//        List<Seat> availableSeats = new ArrayList<>();
//        for (Seat seat : seats) {
//            if (!seat.isReserved()) {
//                availableSeats.add(seat);
//            }
//        }
//        return availableSeats;
//    }

//    public void printSeatAvailability() {
//        for (Seat seat : seats) {
//            System.out.println(seat.rowNum + seat.colNum + " 예약 여부: " + (seat.isReserved() ? "예약됨" : "사용 가능"));
//        }
//    }

    /**
     * 시트 배열 초기화 메소드.
     */
    public void initializeSeats() {
        seats = new Seat[row][col]; // 배열 사이즈 세팅
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                char rowChar = (char) ('A' + i);
                seats[i][j] = new Seat(rowChar, j + 1);
            }
        }
    }

    public void initializeResInfo() {
        try (BufferedReader reader = new BufferedReader(new FileReader(this.respath))) {
            String line;
            int row = 0;
            while ((line = reader.readLine()) != null && row < seats.length) {
                for (int col = 0; col < line.length() && col < seats[row].length; col++) {
                    char ch = line.charAt(col);

                    if (ch == '1') {
                        seats[row][col].reserved = true;
                    }
                    else {
                        seats[row][col].reserved = false;
                    }
                }
                row++;
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + respath);
            e.printStackTrace();
        }
    }

    public void updateFile(String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < seats.length; i++) {
                for (int j = 0; j < seats[i].length; j++) {
                    writer.write(seats[i][j].isReserved() ? '1' : '0'); // 예약된 좌석은 1, 아니면 0
                }
                writer.newLine(); // 줄바꿈
            }
        } catch (IOException e) {
            System.err.println("Error writing to file: " + filePath);
            e.printStackTrace();
        }
    }

    public void removeSeat(ArrayList<Seat> seat) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(respath))) {
            for (int i = 0; i < seats.length; i++) {
                for (int j = 0; j < seats[i].length; j++) {
                    Seat currentSeat = seats[i][j]; // 현재 좌석 가져오기
                    if (seat.contains(currentSeat)) {
                        // 해당 좌석이 리스트에 포함되어 있다면 비활성화 (0)
                        currentSeat.cancelReservation(); // 좌석 상태를 업데이트
                        writer.write("0");
                    } else {
                        // 기존 상태 유지 (1 또는 0)
                        writer.write(currentSeat.isReserved() ? "1" : "0");
                    }
                }
                writer.newLine(); // 각 행 끝에 줄바꿈 추가
            }
        } catch (IOException e) {
            System.err.println("Error writing to file: " + respath);
            e.printStackTrace();
        }
    }

    public String getName() {
        return name;
    }
}
